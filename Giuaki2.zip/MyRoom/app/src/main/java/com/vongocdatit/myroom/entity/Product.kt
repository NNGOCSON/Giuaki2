package com.vongocdatit.myroom.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Product(
    @PrimaryKey
    var code:String,
    var name:String,
    var price:Float = 0.0F)
{
    override fun toString(): String {
        return "$code - $name - $price"
    }
}