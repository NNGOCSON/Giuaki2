package com.vongocdatit.myroom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.room.Room
import com.vongocdatit.myroom.dao.ProductDao
import com.vongocdatit.myroom.database.AppDatabase
import com.vongocdatit.myroom.databinding.ActivityMainBinding
import com.vongocdatit.myroom.entity.Product

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var productDao: ProductDao
    private lateinit var adapter: ArrayAdapter<Product>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //connect database
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,"product.db"
        ).allowMainThreadQueries().build()
        //create object for access methods of ProductDao
        productDao = db.productDao()
        loadData()
        binding.apply {
            btnInsert.setOnClickListener {
                //insert data
                var code = edtCode.text.toString()
                var name = edtName.text.toString()
                var price = edtPrice.text.toString().toFloat()
                var product = Product(code,name,price)
                productDao.insertAll(product)
                loadData()
            }
            btnDelete.setOnClickListener {
                //delete data
                var code = edtCode.text.toString()
                var name = ""//edtName.text.toString()
                var price = 0.0F//edtPrice.text.toString().toFloat()
                var product = Product(code,name,price)
                productDao.delete(product)
                loadData()
            }
            btnUpdate.setOnClickListener {
                //update data
                var code = edtCode.text.toString()
                var name = edtName.text.toString()
                var price = edtPrice.text.toString().toFloat()
                var product = Product(code,name,price)
                productDao.update(product)
                loadData()
            }
        }
    }

    fun loadData(){
        val products:List<Product> = productDao.getAll()
        val list:MutableList<Product> = ArrayList<Product>()
        list.clear()
        for(p in products)
        {
            list.add(p)
        }
        adapter = ArrayAdapter<Product>(this@MainActivity,android.R.layout.simple_list_item_1,list)
        adapter.notifyDataSetChanged()
        binding.lstProduct.adapter = adapter
    }

}