package com.vongocdatit.myroom.dao

import androidx.room.*
import com.vongocdatit.myroom.entity.Product

@Dao
interface ProductDao {
    @Query("select * from product")
    fun getAll():List<Product>
    @Insert
    fun insertAll(vararg products: Product)
    @Delete
    fun delete(product:Product)
    @Update
    fun update(product:Product)
}
